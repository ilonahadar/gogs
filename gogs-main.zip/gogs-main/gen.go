// Copyright 2022 The Gogs Authors. All rights reserved.
// Use of this source code is governed by a MIT-style
// license that can be found in the LICENSE file.

package main

//go:generate go install golang.org/x/tools/cmd/goimports@v0.1.10
//go:generate go run github.com/derision-test/go-mockgen/cmd/go-mockgen@v1.3.7
